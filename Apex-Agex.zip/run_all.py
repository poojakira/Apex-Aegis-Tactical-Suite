import glob, subprocess, sys

for path in glob.glob('**/*.py', recursive=True):
    print('--- executing', path)
    try:
        # skip if this file is the runner itself
        if path.endswith('run_all.py'):
            continue
        subprocess.run([sys.executable, path], check=True)
    except subprocess.CalledProcessError as e:
        print('ERROR', path, e)
